# Calendar
I have developed a C language program that efficiently manages calendars and events. The code features a well-designed interface with options to display monthly and yearly calendars, navigate between adjacent months, jump to specific dates, add events, search existing events, and display them sorted by dates.
